package com.example.wednesdayg.db;

public class DbConstants {
    public static final String TABLE_NAME = "questions.";
    public static final String QUES = "ques";
    public static final String _ID = "_id";
    public static final String ANSWER = "answer";
    public static final String DB_NAME = "db_questions.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_STRUCTURE = "CREATE TABLE IF NOT EXISTS" +
            TABLE_NAME + " (" + _ID + " INTEGER PRIMARY KEY," + QUES + " TEXT," +
            ANSWER + " TEXT)";
    public static final String DROP_TABLE = "DROP TABLE IF EXISTS" + TABLE_NAME;
}
