package com.example.wednesdayg;

public class Json {

    public static final int numbOfQ=25;

    public final static String json="{\n" +
            "\"questions\": {\n" +
            "{\"question_title\": \"Wednesday - это американский телесериал, созданный на основе комиксов?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это продолжение сериала \"The Addams Family\"?\", \"true_answer\": \"false\", \"answer1\": \"true\", },\n" +
            "{\"question_title\": \"Wednesday - это история о дочери семьи Addams?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это комедийный сериал?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Wednesday - это сериал о приключениях молодой девушки, которая ищет свое место в жизни?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это сериал, который проходит в современном мире?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это сериал о мистических существах и явлениях?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это сериал, рассказывающий о том, как молодая девушка становится участником тайной организации?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - это сериал, который получил положительные отзывы критиков?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday - дочь главных героев фильма \"Аддамс семейка\"?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Родители Wednesday незаконно усыновили ее?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Главную роль играет Майли Сайрус?\", \"true_answer\": \"false\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Сериал создан на основе комиксов?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday живет со своей семьей в обычном доме?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Главная героиня обладает сверхъестественными способностями?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday учится в обычной школе?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Сериал вышел в эфир в 2021 году?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Город, в котором происходят события первого сезона сериала Wednesday это Джерико?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Предка wednesday зовут Гина Адамс?\", \"true_answer\": \"false\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday носит только черно-белые наряды?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Сериал снимался в более 100 локациях?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Вещь - компьютерная графика?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Wednesday не моргает?\", \"true_answer\": \"true\", \"answer1\": \"false\" },\n" +
            "{\"question_title\": \"Wednesday пишет книгу\", \"true_answer\": \"true\", \"answer1\": \"false\" }, \n" +
            "{\"question_title\": \"Энид является вампиром?\", \"true_answer\": \"false\", \"answer1\": \"true\" },\n" +
            "{\"question_title\": \"Гомес - отец Wednesday?\", \"true_answer\": \"true\", \"answer1\": \"false\" }\n" +
            "}\n" +
            "}\n";
}